﻿using UnityEngine;
using System.Collections;

public class EnemyTerritory : MonoBehaviour {
	public BoxCollider2D territory;
	private GameObject thePlayer;
	private bool playerInSight;
	public GameObject enemy;
	private SlimeController theSlime;

	// Use this for initialization
	void Start () {
		thePlayer = GameObject.Find ("Player");
		theSlime = enemy.GetComponent<SlimeController>();
		playerInSight = false;
	}
	
	// Update is called once per frame
	void Update ()
	{
		if (playerInSight == true)
		{
			theSlime.MoveToPlayer();
		}

		if (playerInSight == false)
		{
			theSlime.Rest();
		}
	}

	void OnTriggerEnter2D (Collider2D other)
	{
		if (other.gameObject == thePlayer)
		{
			playerInSight = true;
		}
	}

	void OnTriggerExit2D (Collider2D other)
	{
		if (other.gameObject == thePlayer) 
		{
			playerInSight = false;
		}
	}
}
