﻿using UnityEngine;
using System.Collections;

public class PlayerHealthManager : MonoBehaviour {
	public int playerMaxHealth;
	public int playerCurrentHealth;
	private Animator anim;
	private Rigidbody2D myRb;

	// Use this for initialization
	void Start () {
		playerCurrentHealth = playerMaxHealth;
		anim = GetComponent<Animator> ();
		myRb = GetComponent<Rigidbody2D> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (playerCurrentHealth <= 0) {
			anim.SetBool("death", true);
			myRb.velocity = Vector2.zero;
		}
	}

	public void HurtPlayer(int damageToGive)
	{
		playerCurrentHealth -= damageToGive;
	}

	public void SetMaxHealth()
	{
		playerCurrentHealth = playerMaxHealth;
	}
}
